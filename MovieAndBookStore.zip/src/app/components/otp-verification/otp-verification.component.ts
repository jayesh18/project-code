import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.component.html',
  styleUrls: ['./otp-verification.component.css']
})
export class OtpVerificationComponent implements OnInit {
  otp = '';
  isTrue: boolean;
  firstClick = false;

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  verifyOTP() {
    this.firstClick = true;
    if (this.otp === '778899') {
      this.isTrue = true;
      alert("otp is verfied and your order has been placed and thank you for shopping")
      this.router.navigate(['/Catalog'])
    } else {
      this.isTrue = false;
    }
  }


}
