import { Component, OnInit } from '@angular/core';
import{MoviesService } from 'src/app/services/movies.service';
import { Movie } from 'src/app/models/movie';
import {NgbPaginationConfig} from '@ng-bootstrap/ng-bootstrap';




@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css'],
  providers:[NgbPaginationConfig]

})
export class MovieComponent implements OnInit {
  page = 1;
  pageSize = 3;
  movieList:Movie[] = []
  constructor(private movieservice:MoviesService,config: NgbPaginationConfig) {
    config.size = 'sm';
    config.boundaryLinks = true;

   }

  ngOnInit(): void {

    this.movieservice.getMovies().subscribe((movies) =>{

this.movieList = movies;

    })
  }

}
