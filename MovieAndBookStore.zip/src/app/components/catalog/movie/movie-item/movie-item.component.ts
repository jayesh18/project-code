import { Component, OnInit,Input} from '@angular/core';
import { Movie } from 'src/app/models/movie';
import {MessengerService} from 'src/app/services/messenger.service';
import{CartService } from 'src/app/services/cart.service'
import { MoviesService } from 'src/app/services/movies.service';
import{Cart} from 'src/app/models/cart';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';
@Component({
  selector: 'app-movie-item',
  templateUrl: './movie-item.component.html',
  styleUrls: ['./movie-item.component.css']
})
export class MovieItemComponent implements OnInit {
  cartItem:Cart[];
  wishListMovie:Wishlist[];
  addedToWishlist: boolean;
  movieList:any[]
  @Input() movieItem:Movie

  constructor(
    private msg:MessengerService,
    private cartservice:CartService,
    private movieservice:MoviesService,
    private wishservice:WishlistService
    ) {

   }

  ngOnInit(): void {

    this.cartItem=this.cartservice.getItems()
    this.wishListMovie = this.wishservice.getWishlistMovie()
    this.movieservice.getMovies().subscribe((movies) =>{

      this.movieList = movies;
     
  })
 
}




AddToCart(product:Movie){
let productExist = false;

for(let i in this.cartItem){

if(this.cartItem[i].name === product.name){

this.cartItem[i].quantity++
product.quantity--
productExist = true
break;

}

}

if(!productExist){
  product.quantity--
this.cartservice.addToCart({
  
  name:product.name,
  releaseYear:product.releaseYear,
  genre:product.genre,
  amount:product.amount,
  image:product.image,
  quantity:1,
  description:product.description,
  author_director:product.director,
  type:product.type

 


});
}

}

AddToWishlist(product:Movie){
  let productExist = false;
  
  for(let i in this.wishListMovie){
  
  if(this.wishListMovie[i].name === product.name){
    this.addedToWishlist = true;
    alert("item Already In Wishlist")
    productExist = true;
 
  break;
  
  }
  
  }
  
  if(!productExist){
  
  this.wishservice.addToWishListMovie({
    
    id:product.id,
    name:product.name,
    releaseYear:product.releaseYear,
    genre:product.genre,
    amount:product.amount,
    image:product.image,
    quantity:product.quantity,
    description:product.description,
    type:product.type
      
    
  

  });
  this.addedToWishlist = true
  }
  
  }


}
