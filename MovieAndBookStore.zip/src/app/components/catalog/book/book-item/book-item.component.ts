import { Component, OnInit,Input } from '@angular/core';
import { Book } from 'src/app/models/book';
import { CartService } from 'src/app/services/cart.service';
import{Cart} from 'src/app/models/cart';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';
@Component({
  selector: 'app-book-item',
  templateUrl: './book-item.component.html',
  styleUrls: ['./book-item.component.css']
})
export class BookItemComponent implements OnInit {
  cartItem:Cart[]
  wishListBook:Wishlist[];
  addedToWishlist: boolean;
  @Input() bookItem:Book;
  constructor(private cartservice:CartService,private wishservice:WishlistService) { }

  ngOnInit(): void {
    this.wishListBook = this.wishservice.getWishlistBook()
    this.cartItem = this.cartservice.getItems()
  }
  AddToCart(product:Book){
    let productExist = false;
    
    for(let i in this.cartItem){
    
    if(this.cartItem[i].name === product.name){
    
    this.cartItem[i].quantity++
    product.quantity--
    productExist = true
    break;
    
    }
    
    }
    
    if(!productExist){
      product.quantity--
    this.cartservice.addToCart({
  name:product.name,
  releaseYear:product.releaseYear,
  genre:product.genre,
  amount:product.amount,
  image:product.image,
  quantity:1,
  description:product.description,
  author_director:product.writer,
  type:product.type
    
    });
    }
    
    }
    
AddToWishlist(product:Book){
  let productExist = false;
  
  for(let i in this.wishListBook){
  
  if(this.wishListBook[i].name === product.name){
    this.addedToWishlist = true;
    alert("item Already In Wishlist")
    productExist = true;
 
  break;
  
  }
  
  }
  
  if(!productExist){
  
  this.wishservice.addToWishListBook({
    
    id:product.id,
    name:product.name,
    releaseYear:product.releaseYear,
    genre:product.genre,
    amount:product.amount,
    image:product.image,
    quantity:product.quantity,
    description:product.description,
    type:product.type

  

  });
  this.addedToWishlist = true
  }
}
    
    }

