import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/models/book';
import{BookService } from 'src/app/services/book.service';
import {NgbPaginationConfig} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css'],
  providers:[NgbPaginationConfig]
})
export class BookComponent implements OnInit {
  page = 1;
  pageSize = 3;

bookList:Book[] = []
  constructor(private bookservice:BookService,config: NgbPaginationConfig) { 
    config.size = 'sm';
    config.boundaryLinks = true;


  }

  ngOnInit(): void {
    this.bookservice.getBooks().subscribe((books) =>{

      this.bookList = books;
      
          })

}
}
