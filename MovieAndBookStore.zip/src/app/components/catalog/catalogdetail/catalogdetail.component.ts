import { Component, OnInit } from '@angular/core';
import { Movie } from "src/app/models/movie";
import { Observable } from "rxjs";
import { switchMap } from "rxjs/operators";
import { ParamMap, ActivatedRoute, Router } from "@angular/router";
import { MoviesService } from "src/app/services/movies.service";
import { NgbRatingConfig } from "@ng-bootstrap/ng-bootstrap";
import { Book } from 'src/app/models/book';
import { BookService } from 'src/app/services/book.service';
import { Cart } from 'src/app/models/cart';
import { CartService } from 'src/app/services/cart.service';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';

@Component({
  selector: 'app-catalogdetail',
  templateUrl: './catalogdetail.component.html',
  styleUrls: ['./catalogdetail.component.css']
})
export class CatalogdetailComponent implements OnInit {
  movie: Observable<Movie>
  cartItem:Cart[]
  wishListMovie:Wishlist[];
  wishListBook:Wishlist[];
  addedToWishlist: boolean;
  book:Observable<Book>
  displayMovies:boolean
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private moviesService: MoviesService,
    private config: NgbRatingConfig,
    private cartservice:CartService,
    private bookservice:BookService,
    private wishservice:WishlistService
  ) { }

  ngOnInit(): void {
    this.wishListMovie = this.wishservice.getWishlistMovie()
    this.wishListBook = this.wishservice.getWishlistBook()
    this.cartItem=this.cartservice.getItems()
    this.route.data.subscribe(
      (data) => {
        this.displayMovies = data.type === 'movie';
      }
    );
    this.movie = this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        this.moviesService.getMovie(params.get("id"))
      )
    );
    this.book = this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        this.bookservice.getBook(params.get("id"))
      )
    );
  }
  AddToCart(product){

    let productExist = false;
    
    for(let i in this.cartItem){
    
    if(this.cartItem[i].name === product.name){
    
    this.cartItem[i].quantity++
    product.quantity--
    productExist = true
    break;
    
    }
    
    }
    
    if(!productExist){
      product.quantity--
    this.cartservice.addToCart({
  name:product.name,
  releaseYear:product.releaseYear,
  genre:product.genre,
  amount:product.amount,
  image:product.image,
  quantity:1,
  description:product.description,
  author_director:product.writer,
  type:product.type
    
    });
    }
    
    }
    AddToWishlist(product,type){
      let productExist = false;
      if(type=="movie"){
      for(let i in this.wishListMovie){
      
      if(this.wishListMovie[i].name === product.name){
        this.addedToWishlist = true;
        alert("item Already In Wishlist")
        productExist = true;
     
      break;
      
      }
    }
      }
      else{

        for(let i in this.wishListBook){
      
          if(this.wishListBook[i].name === product.name){
            this.addedToWishlist = true;
            alert("item Already In Wishlist")
            productExist = true;
         
          break;
          
          }
        }

      }
      
      if(!productExist){
      if(type=='movie'){
      this.wishservice.addToWishListMovie({
        
        id:product.id,
        name:product.name,
        releaseYear:product.releaseYear,
        genre:product.genre,
        amount:product.amount,
        image:product.image,
        quantity:product.quantity,
        description:product.description,
        type:product.type
    
      
    
      });
      this.addedToWishlist = true
      }
      else{

        this.wishservice.addToWishListBook({
        
          id:product.id,
          name:product.name,
          releaseYear:product.releaseYear,
          genre:product.genre,
          amount:product.amount,
          image:product.image,
          quantity:product.quantity,
          description:product.description,
          type:product.type
      
        
      
        });
        this.addedToWishlist = true
        }

      }
    }

}
