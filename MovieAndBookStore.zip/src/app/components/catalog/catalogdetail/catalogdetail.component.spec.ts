import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CatalogdetailComponent } from './catalogdetail.component';

describe('CatalogdetailComponent', () => {
  let component: CatalogdetailComponent;
  let fixture: ComponentFixture<CatalogdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CatalogdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CatalogdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
