import { Component, OnInit,Input } from '@angular/core';
import { Wishlist } from 'src/app/models/wishlist';
import { CartService } from 'src/app/services/cart.service';
import{Cart} from 'src/app/models/cart';
@Component({
  selector: 'app-wishlist-book-item',
  templateUrl: './wishlist-book-item.component.html',
  styleUrls: ['./wishlist-book-item.component.css']
})
export class WishlistBookItemComponent implements OnInit {
  @Input() bookItem:Wishlist
  cartItem:Cart[]
  constructor(private cartservice:CartService) { }

  ngOnInit(): void {
    this.cartItem = this.cartservice.getItems()
  }

  AddToCart(product){

    let productExist = false;
    
    for(let i in this.cartItem){
    
    if(this.cartItem[i].name === product.name){
    
    this.cartItem[i].quantity++
    product.quantity--
    productExist = true
    break;
    
    }
    
    }
    
    if(!productExist){
      product.quantity--
    this.cartservice.addToCart({
  name:product.name,
  releaseYear:product.releaseYear,
  genre:product.genre,
  amount:product.amount,
  image:product.image,
  quantity:1,
  description:product.description,
  author_director:product.writer,
  type:product.type
    
    });
    }
  }
}
