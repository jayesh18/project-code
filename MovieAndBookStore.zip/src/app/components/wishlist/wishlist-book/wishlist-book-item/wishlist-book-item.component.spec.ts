import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistBookItemComponent } from './wishlist-book-item.component';

describe('WishlistBookItemComponent', () => {
  let component: WishlistBookItemComponent;
  let fixture: ComponentFixture<WishlistBookItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WishlistBookItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WishlistBookItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
