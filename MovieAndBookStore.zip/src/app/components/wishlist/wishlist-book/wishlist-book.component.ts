import { Component, OnInit } from '@angular/core';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';
@Component({
  selector: 'app-wishlist-book',
  templateUrl: './wishlist-book.component.html',
  styleUrls: ['./wishlist-book.component.css']
})
export class WishlistBookComponent implements OnInit {
 bookList :Wishlist[];
  constructor(private wishservice:WishlistService) { }

  ngOnInit(): void {
    this.bookList = JSON.parse(localStorage.getItem("book"))
    this.bookList = this.wishservice.getWishlistBook()

  }
  clearall(){
    this.bookList=this.wishservice.clearWishlistBook();

  }
}
