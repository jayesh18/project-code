import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistMovieItemComponent } from './wishlist-movie-item.component';

describe('WishlistMovieItemComponent', () => {
  let component: WishlistMovieItemComponent;
  let fixture: ComponentFixture<WishlistMovieItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WishlistMovieItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WishlistMovieItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
