import { Component, OnInit,Input } from '@angular/core';
import { Wishlist } from 'src/app/models/wishlist';
import { CartService } from 'src/app/services/cart.service';
import{Cart} from 'src/app/models/cart';

@Component({
  selector: 'app-wishlist-movie-item',
  templateUrl: './wishlist-movie-item.component.html',
  styleUrls: ['./wishlist-movie-item.component.css']
})
export class WishlistMovieItemComponent implements OnInit {
  @Input() movieItem:Wishlist
  cartItem:Cart[]
  constructor(private cartservice:CartService) { }

  ngOnInit(): void {
    localStorage.setItem("MovieWishList", JSON.stringify(this.movieItem));
    let users = JSON.parse(localStorage.getItem('users')) || [];
    this.movieItem = JSON.parse(localStorage.getItem('MovieWishList')) || [];
    this.cartItem = this.cartservice.getItems()
  }

  AddToCart(product){

    let productExist = false;
    
    for(let i in this.cartItem){
    
    if(this.cartItem[i].name === product.name){
    
    this.cartItem[i].quantity++
    product.quantity--
    productExist = true
    break;
    
    }
    
    }
    
    if(!productExist){
      product.quantity--
    this.cartservice.addToCart({
  name:product.name,
  releaseYear:product.releaseYear,
  genre:product.genre,
  amount:product.amount,
  image:product.image,
  quantity:1,
  description:product.description,
  author_director:product.writer,
  type:product.type
    
    });
    }
    
    }
}
