import { Component, OnInit } from '@angular/core';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';

@Component({
  selector: 'app-wishlist-movie',
  templateUrl: './wishlist-movie.component.html',
  styleUrls: ['./wishlist-movie.component.css']
})
export class WishlistMovieComponent implements OnInit {
  movieList :Wishlist[];
  constructor(private wishservic:WishlistService) { }

  ngOnInit(): void {
    this.movieList = JSON.parse(localStorage.getItem("movie"))
    this.movieList = this.wishservic.getWishlistMovie()
  }
clearAll(){

this.movieList=this.wishservic.clearWishlistMovie();

}
}
