import { Component, OnInit } from '@angular/core';
import{Wishlist} from 'src/app/models/wishlist';
import { WishlistService } from 'src/app/services/wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  active = 1;
  constructor(
private wishservice : WishlistService

  ) { }

  ngOnInit(): void {

  }

}
