import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import{Cart} from 'src/app/models/cart';
import{UserService} from 'src/app/services/user.service';
import{User} from 'src/app/models/user';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  user:User[] = [];
  cartItems:Cart[];
  cartTotal = 0;
  quantity:number

  constructor(private cartservice:CartService,private userservice:UserService) {

  }


  ngOnInit(){

    this.cartItems = this.cartservice.getItems();
    this.user = this.userservice.getUser();
    console.log(this.user)
   
  }
  ngDoCheck(){
  this.cartTotal = 0;
  this.cartItems.forEach(item => {
     this.cartTotal += (item.quantity * item.amount)
   } )
  }
  clearItem(cartItem){
    this.cartservice.clearitem(cartItem)
    
    }
    clearall(){
this.cartItems= this.cartservice.clearCart();

    }
}
