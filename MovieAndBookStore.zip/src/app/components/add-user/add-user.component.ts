import { Component, OnInit } from '@angular/core';
import{FormBuilder,Validators} from '@angular/forms';
import{User} from 'src/app/models/user';
import { Router, RouterModule } from '@angular/router';
import{UserService} from 'src/app/services/user.service';
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
user:any[]
submitted=false;
  constructor(private fb:FormBuilder,private userservice:UserService, private router: Router) { }

  ngOnInit(): void {

  }
  ngDoCheck(){
  }

  UserProfileForm = this.fb.group({
     Name:['',Validators.required],
     Email:['',Validators.required],
     Address:['',Validators.required],
     Street:['',Validators.required],
     City:['',Validators.required],
     Zipcode:['',Validators.required],
     Country:['',Validators.required],
     UpiId:['',Validators.required]




  })

  onSubmit(){
this.userservice.addUser(this.UserProfileForm.value)
this.router.navigate(['/Checkout'])
  }

  // OnGet(){

  //  this.user = this.userservice.getUser();

  // }

}
