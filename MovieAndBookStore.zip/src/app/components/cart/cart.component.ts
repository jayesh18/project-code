import { Component, OnInit } from '@angular/core';
import {MessengerService} from 'src/app/services/messenger.service';
import { Movie } from 'src/app/models/movie';
import { CartService } from 'src/app/services/cart.service';
import{Cart} from 'src/app/models/cart';
import{UserService} from'src/app/services/user.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cartItems:Cart[];
  User:any[];
  userAdded:boolean=false;
  cartTotal = 0;
  quantity:number


  constructor(private msg:MessengerService,
    private cartservice:CartService,
    private userservice:UserService) {

  }

  ngOnInit(){

    this.cartItems = this.cartservice.getItems();
    this.User=this.userservice.getUser()

   
  }
  ngDoCheck(){
  this.cartTotal = 0;
  this.cartItems.forEach(item => {
     this.cartTotal += (item.quantity * item.amount)
   } )
   if(this.User.length>0){
    this.userAdded = true;

   }
  }
  clearItem(cartItem){
    this.cartservice.clearitem(cartItem)
    
    }
    clearall(){
this.cartItems= this.cartservice.clearCart();

    }
}

