import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CatalogComponent } from './components/catalog/catalog.component';
import { CartComponent } from './components/cart/cart.component';
import { CatalogdetailComponent } from './components/catalog/catalogdetail/catalogdetail.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { OtpVerificationComponent } from './components/otp-verification/otp-verification.component';


const routes: Routes = [
  {path:'',redirectTo:'/Catalog',pathMatch:'full'},
  {path:'Catalog',component:CatalogComponent, data: {type: 'movie'}},
  {path:'Cart',component:CartComponent},
  {path:'Confirm',component:OtpVerificationComponent},
  {path:'Wishlist',component:WishlistComponent},
  {path:'User',component:AddUserComponent},
  {path:'Checkout',component:CheckoutComponent},
  { path: "movies/:id", component: CatalogdetailComponent, data: { type: 'movie' } },
  { path: "books/:id", component: CatalogdetailComponent, data: { type: 'book' }},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
