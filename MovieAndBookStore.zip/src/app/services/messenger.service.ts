import { Injectable } from '@angular/core';
import { Subject} from 'rxjs';
import { CartService } from './cart.service';

@Injectable()
export class MessengerService {

  subject = new Subject ()
  constructor(private cartservice:CartService) { }

  sendMsg(product){
   this.subject.next(product);
   
  }

  getMsg(){
  return this.subject.asObservable()
  }
}
