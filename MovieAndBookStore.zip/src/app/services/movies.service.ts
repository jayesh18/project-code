import { Injectable } from '@angular/core';
import { Movie } from "src/app/models/movie";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/internal/operators/map";
const apiUrl = "http://localhost:3000/movies";
@Injectable({
  providedIn: 'root'
})
export class MoviesService {


  constructor(private http:HttpClient) { }

  getMovies():Observable<Movie[]>{
    return this.http.get<Movie[]>(apiUrl);
  }
  getMovie(index: number | string) {
    return this.getMovies().pipe(
      map((movies: Movie[]) => movies.find((movie) => movie.id == index))
    );
  }
  }


