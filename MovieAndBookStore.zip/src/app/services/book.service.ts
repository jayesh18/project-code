import { Injectable } from '@angular/core';
import { Book } from "src/app/models/book";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/internal/operators/map";
const apiUrl = "http://localhost:3000/books";
@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http:HttpClient) { }
  getBooks():Observable<Book[]>{
    return this.http.get<Book[]>(apiUrl);
  }
  getBook(index: number | string) {
    return this.getBooks().pipe(
      map((books: Book[]) => books.find((book) => book.id == index))
    );
  }
}
