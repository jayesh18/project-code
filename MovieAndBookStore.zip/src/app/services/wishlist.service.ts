import { Injectable } from '@angular/core';
import {Wishlist} from 'src/app/models/wishlist';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  wishlistsMovie:Wishlist[]=[];
  wishlistBook:Wishlist[] = [];

  addToWishListMovie(product) {
    this.wishlistsMovie.push(product)
    localStorage.setItem("movie",JSON.stringify(product));
  }

  getWishlistMovie() {
    return this.wishlistsMovie;
  }
  clearitemMovie(item){

    this.wishlistsMovie.pop()

  }

  clearWishlistMovie() {
    this.wishlistsMovie = [];
    return this.wishlistsMovie;
  }


  addToWishListBook(product) {
    this.wishlistBook.push(product);
    localStorage.setItem("book",JSON.stringify(product));
  }

  getWishlistBook() {
    return this.wishlistBook;
  }
  clearitemBook(item){

    this.wishlistBook.pop()

  }

  clearWishlistBook() {
    this.wishlistBook = [];
    return this.wishlistBook;
  }
  constructor() { }
}
