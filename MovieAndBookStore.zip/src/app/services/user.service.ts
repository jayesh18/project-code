import { Injectable } from '@angular/core';
import {User} from 'src/app/models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
user:User[]=[];

  constructor() { }

addUser(profile){
  console.log(profile)
this.user.push(profile);

}

getUser(){
return this.user;

}

}
