import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import {FormsModule} from '@angular/forms'; 
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { NavComponent } from './components/shared/nav/nav.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { CatalogComponent } from './components/catalog/catalog.component';
import{ReactiveFormsModule} from '@angular/forms';
import { CartComponent } from './components/cart/cart.component';
import { MovieComponent } from './components/catalog/movie/movie.component';
import { MovieItemComponent } from './components/catalog/movie/movie-item/movie-item.component';
import { BookComponent } from './components/catalog/book/book.component';
import { BookItemComponent } from './components/catalog/book/book-item/book-item.component';
import { MoviesService } from './services/movies.service';
import { BookService } from './services/book.service';
import { MessengerService } from './services/messenger.service';
import { Movie } from 'src/app/models/movie';
import { CatalogdetailComponent } from './components/catalog/catalogdetail/catalogdetail.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { WishlistItemComponent } from './components/wishlist/wishlist-item/wishlist-item.component';
import { WishlistBookComponent } from './components/wishlist/wishlist-book/wishlist-book.component';
import { WishlistBookItemComponent } from './components/wishlist/wishlist-book/wishlist-book-item/wishlist-book-item.component';
import { WishlistMovieComponent } from './components/wishlist/wishlist-movie/wishlist-movie.component';
import { WishlistMovieItemComponent } from './components/wishlist/wishlist-movie/wishlist-movie-item/wishlist-movie-item.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { OtpVerificationComponent } from './components/otp-verification/otp-verification.component';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavComponent,
    FooterComponent,
    CatalogComponent,
    CartComponent,
    MovieComponent,
    MovieItemComponent,
    BookComponent,
    BookItemComponent,
    CatalogdetailComponent,
    WishlistComponent,
    WishlistItemComponent,
    WishlistBookComponent,
    WishlistBookItemComponent,
    WishlistMovieComponent,
    WishlistMovieItemComponent,
    AddUserComponent,
    CheckoutComponent,
    OtpVerificationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
 
  ],
  providers: [
 MoviesService,
 BookService,
 MessengerService


  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
