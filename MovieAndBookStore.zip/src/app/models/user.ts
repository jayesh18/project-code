export class User {
  public id: number;
  public Name: string;
  public Email: string;
  public Address: string;
  public Street: string;
  public City: string;
  public Zipcode: number;
  public Country: string;
  public UpiId: number;
  

  constructor(
    id: number,
    Name: string,
    Email: string,
    Address: string,
    Street: string,
    City: string,
    Zipcode: number,
    Country: string,
    UpiId: number,
  ) {
    this.id = id;
    this.Name = Name;
    this.Email = Email;
    this.Address = Address;
    this.Street = Street;
    this.City = City;
    this.Zipcode = Zipcode;
    this.Country = Country;
    this.UpiId = UpiId;
  }
}
