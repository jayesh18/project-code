export class Cart {
    public id: number;
    public name: string;
    public releaseYear: number;
    public genre: string;
    public amount: number;
    public image: string;
    public quantity: number;
    public description: string;
    public author_director: string;
    public type:string;
  
    constructor(
      id: number,
      name: string,
      releaseYear: number,
      genre: string,
      amount: number,
      image: string,
      quantity: number,
      description: string,
      author_director: string,
      writer: string,
      type: string

    ) 
    {
     this.id = id;
      this.name = name;
      this.releaseYear = releaseYear;
      this.genre = genre;
      this.amount = amount;
      this.image = image;
      this.quantity = quantity;
      this.description = description;
      this.author_director = author_director;
      this.type = type;
    }
  }
  