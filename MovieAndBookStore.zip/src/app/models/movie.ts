
export class Movie {
  public id: number;
  public name: string;
  public releaseYear: number;
  public genre: string;
  public amount: number;
  public image: string;
  public quantity: number;
  public description: string;
  public trailer: string;
  public rating: number;
  public director: string;
  public cast: string;
  public type:string;

  constructor(
    id: number,
    name: string,
    releaseYear: number,
    genre: string,
    amount: number,
    image: string,
    quantity: number,
    description: string,
    trailer: string,
    rating: number,
    director: string,
    cast: string,
    type:string
  ) {
    this.id = id;
    this.name = name;
    this.releaseYear = releaseYear;
    this.genre = genre;
    this.amount = amount;
    this.image = image;
    this.quantity = quantity;
    this.description = description;
    this.trailer = trailer;
    this.rating = rating;
    this.director = director;
    this.cast = cast;
    this.type = type;
  }
}
